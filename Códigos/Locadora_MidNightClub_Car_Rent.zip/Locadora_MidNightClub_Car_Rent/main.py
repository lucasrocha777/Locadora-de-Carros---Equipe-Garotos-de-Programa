from flask import Flask, render_template, request, redirect, url_for, flash, session
from datetime import datetime
from classes import Locadora, Carro, Moto, Cliente, Reserva, db, Veiculo
import os
import logging

app = Flask(__name__)
app.secret_key = "chave_secreta"

basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'locadora.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

with app.app_context():
    db.create_all()

locadora = Locadora("Midnight Car Rent", "12.345.678/0001-99", "Rua das Locações, 123")

with app.app_context():
    if not Veiculo.query.filter_by(placa="ABC-1234").first():
        carro1 = Carro('carro',"Toyota", "Corolla", "ABC-1234", 2022, "Prata", "Disponível", 150, "Gasolina", 4)
        db.session.add(carro1)
        print(f"Veículo adicionado: {carro1.marca} {carro1.modelo}")

    if not Veiculo.query.filter_by(placa="XYZ-5678").first():
        carro2 = Carro('carro',"Jeep", "Renegade", "XYZ-5678", 2023, "Vermelho", "Disponível", 180, "Gasolina", 4)
        db.session.add(carro2)
        print(f"Veículo adicionado: {carro2.marca} {carro2.modelo}")

    if not Veiculo.query.filter_by(placa="OPA-1974").first():
        carro3 = Carro('carro',"Chevrolet", "Opala SS", "OPA-1974", 1974, "Preto", "Disponível", 300, "Gasolina", 2)
        db.session.add(carro3)
        print(f"Veículo adicionado: {carro3.marca} {carro3.modelo}")

    if not Veiculo.query.filter_by(placa="GTR-R34").first():
        carro4 = Carro('carro',"Nissan", "GTR R34 Skyline", "GTR-R34", 1999, "Azul", "Disponível", 500, "Gasolina", 2)
        db.session.add(carro4)
        print(f"Veículo adicionado: {carro4.marca} {carro4.modelo}")

    if not Veiculo.query.filter_by(placa="LMK-2023").first():
        carro5 = Carro('carro',"Pixar", "Relâmpago Marquinhos", "LMK-2023", 2023, "Vermelho", "Disponível", 400, "Gasolina", 2)
        db.session.add(carro5)
        print(f"Veículo adicionado: {carro5.marca} {carro5.modelo}")

    if not Veiculo.query.filter_by(placa="JET-2025").first():
        carro6 = Carro('carro',"Volkswagen", "Jetta GLI", "JET-2025", 2025, "Cinza", "Disponível", 250, "Gasolina", 4)
        db.session.add(carro6)
        print(f"Veículo adicionado: {carro6.marca} {carro6.modelo}")

    if not Veiculo.query.filter_by(placa="DEF-9012").first():
        moto1 = Moto('moto',"Honda", "CB500", "DEF-9012", 2021, "Preta", "Disponível", 90, 500, True)
        db.session.add(moto1)
        print(f"Veículo adicionado: {moto1.marca} {moto1.modelo}")

    if not Veiculo.query.filter_by(placa="CGC-2025").first():
        moto2 = Moto('moto',"Honda", "CG 160 Cargo", "CGC-2025", 2025, "Vermelha", "Disponível", 80, 160, False)
        db.session.add(moto2)
        print(f"Veículo adicionado: {moto2.marca} {moto2.modelo}")

    if not Veiculo.query.filter_by(placa="CGT-2025").first():
        moto3 = Moto('moto',"Honda", "CG 160 Titan", "CGT-2025", 2025, "Preta", "Disponível", 85, 160, False)
        db.session.add(moto3)
        print(f"Veículo adicionado: {moto3.marca} {moto3.modelo}")

    if not Veiculo.query.filter_by(placa="MT07-2025").first():
        moto4 = Moto('moto',"Yamaha", "MT07", "MT07-2025", 2025, "Azul", "Disponível", 150, 700, True)
        db.session.add(moto4)
        print(f"Veículo adicionado: {moto4.marca} {moto4.modelo}")

    if not Veiculo.query.filter_by(placa="SPT-2025").first():
        moto5 = Moto('moto',"Harley-Davidson", "Sportster", "SPT-2025", 2025, "Preto", "Disponível", 200, 1200, True)
        db.session.add(moto5)
        print(f"Veículo adicionado: {moto5.marca} {moto5.modelo}")

    db.session.commit()

@app.before_request
def limpar_sessao_se_cliente_nao_existe():
    if 'cliente_id' in session:
        cliente = Cliente.query.get(session['cliente_id'])
        if not cliente:
            session.clear()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/sobre')
def sobre():
    return render_template('sobre.html')

@app.route('/cadastrar_cliente', methods=['GET', 'POST'])
def cadastrar_cliente():
    if request.method == 'POST':
        nome = request.form['nome']
        cpf = request.form['cpf']
        email = request.form['email']
        telefone = request.form['telefone']
        senha = request.form['senha']

        cliente_existente = Cliente.query.filter((Cliente.cpf == cpf) | (Cliente.email == email)).first()
        if cliente_existente:
            flash("CPF ou Email já cadastrado.", "danger")
            return redirect(url_for('cadastrar_cliente'))

        novo_cliente = Cliente(nome=nome, cpf=cpf, email=email, telefone=telefone, senha=senha)
        db.session.add(novo_cliente)
        db.session.commit()

        # Adiciona o ID do cliente à sessão para logar automaticamente
        session['cliente_id'] = novo_cliente.id

        flash(f"Cliente {nome} cadastrado com sucesso!", "success")
        return redirect(url_for('listar_veiculos'))  # Redireciona para a lista de veículos

    return render_template('cadastro.html')

@app.route('/login', methods=['POST'])
def login():
    email = request.form.get('email')
    senha = request.form.get('senha')
    cliente = Cliente.query.filter_by(email=email).first()
    
    if cliente and cliente.senha == senha:
        session['cliente_id'] = cliente.id
        flash('Login realizado com sucesso!', 'success')
        return redirect(url_for('perfil'))
    else:
        flash('Credenciais inválidas. Tente novamente.', 'danger')
        return redirect(url_for('cadastrar_cliente'))
    
@app.context_processor
def inject_classes():
    return dict(Cliente=Cliente)

@app.route('/perfil')
def perfil():
    if 'cliente_id' not in session:
        flash('Faça login para acessar seu perfil.', 'danger')
        return redirect(url_for('cadastrar_cliente'))
    
    cliente = Cliente.query.get(session['cliente_id'])
    if not cliente:
        session.clear()  # Limpa a sessão se o cliente não for encontrado
        flash('Cliente não encontrado.', 'danger')
        return redirect(url_for('home'))
    
    return render_template('perfil.html', cliente=cliente)

@app.route('/veiculos')
def listar_veiculos():
    if 'cliente_id' not in session:
        flash('Faça login para acessar esta página.', 'danger')
        return redirect(url_for('home'))

    # Atualiza o status dos veículos antes de consultar
    veiculos = Veiculo.query.all()
    for veiculo in veiculos:
        veiculo.atualizar_status()
    db.session.commit()

    # Agora, filtre novamente para obter apenas os disponíveis
    veiculos_disponiveis = Veiculo.query.filter_by(status="Disponível").all()

    return render_template('veiculos.html', veiculos=veiculos_disponiveis)

@app.route('/reservar/<placa>', methods=['GET', 'POST'])
def reservar_veiculo(placa):
    if 'cliente_id' not in session:
        flash('Faça login para reservar um veículo.', 'danger')
        return redirect(url_for('cadastrar_cliente'))

    veiculo = Veiculo.query.filter_by(placa=placa).first()
    cliente = Cliente.query.get(session['cliente_id'])

    if request.method == 'POST':
        data_inicio = datetime.strptime(request.form['data_inicio'], "%Y-%m-%d").date()
        data_fim = datetime.strptime(request.form['data_fim'], "%Y-%m-%d").date()

        if data_inicio >= data_fim:
            flash("Erro: A data de fim deve ser posterior à data de início.", "danger")
            return redirect(url_for('reservar_veiculo', placa=placa))

        valor_total = veiculo.valor_diaria * (data_fim - data_inicio).days

        nova_reserva = Reserva(cliente, veiculo, data_inicio, data_fim, valor_total)
        db.session.add(nova_reserva)

        veiculo.status = "Reservado"
        db.session.commit()

        flash(f"Reserva efetuada com sucesso para {veiculo.descricao()}.", "success")
        return redirect(url_for('listar_veiculos'))

    return render_template('reservar.html', veiculo=veiculo)



@app.route('/logout')
def logout():
    logging.info(f'Usuário {session.get("cliente_id")} fez logout.')
    session.clear()
    flash('Logout realizado com sucesso.', 'success')
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)