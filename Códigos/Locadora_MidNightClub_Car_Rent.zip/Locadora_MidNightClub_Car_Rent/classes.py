from flask_sqlalchemy import SQLAlchemy
from datetime import datetime  # ← este import é essencial

db = SQLAlchemy()

class Veiculo(db.Model):
    __tablename__ = 'veiculo'
    id = db.Column(db.Integer, primary_key=True)
    tipo_veiculo = db.Column(db.String(50))
    marca = db.Column(db.String(100))
    modelo = db.Column(db.String(100))
    placa = db.Column(db.String(10), unique=True)
    ano = db.Column(db.Integer)
    cor = db.Column(db.String(20))
    status = db.Column(db.String(20))
    valor_diaria = db.Column(db.Float)

    reservas = db.relationship('Reserva', back_populates='veiculo', lazy=True)

    def __init__(self, tipo_veiculo, marca, modelo, placa, ano, cor, status, valor_diaria):
        self.tipo_veiculo = tipo_veiculo
        self.marca = marca
        self.modelo = modelo
        self.placa = placa
        self.ano = ano
        self.cor = cor
        self.status = status
        self.valor_diaria = valor_diaria

    def descricao(self):
        return f"{self.marca} {self.modelo} ({self.ano}) - {self.cor}"

    @property
    def tipo(self):
        return self.tipo_veiculo.lower()

    def atualizar_status(self):
        hoje = datetime.now().date()  # ← datetime é usado aqui
        for reserva in self.reservas:
            if reserva.data_inicio <= hoje <= reserva.data_fim:
                self.status = "Reservado"
                return
        self.status = "Disponível"

class Cliente(db.Model):
    __tablename__ = 'cliente'
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100))
    cpf = db.Column(db.String(14), unique=True)
    email = db.Column(db.String(100), unique=True)
    telefone = db.Column(db.String(20))
    senha = db.Column(db.String(100))

    # Adicione essa linha abaixo:
    reservas = db.relationship('Reserva', back_populates='cliente', lazy=True)

    def __init__(self, nome, cpf, email, telefone, senha):
        self.nome = nome
        self.cpf = cpf
        self.email = email
        self.telefone = telefone
        self.senha = senha


class Locadora:
    def __init__(self, nome, cnpj, endereco):
        self.nome = nome
        self.cnpj = cnpj
        self.endereco = endereco

    def listar_veiculos_disponiveis(self):
        return Veiculo.query.filter_by(status="Disponível").all()

    def reservar_veiculo(self, cliente, veiculo, data_inicio, data_fim):
        if veiculo.status != "Disponível":
            raise ValueError("Veículo não está disponível para reserva.")
        
        for reserva in veiculo.reservas:
            if reserva.data_inicio <= data_fim and reserva.data_fim >= data_inicio:
                raise ValueError(f"Veículo já reservado entre {reserva.data_inicio} e {reserva.data_fim}.")
        
        dias = (data_fim - data_inicio).days
        valor_total = veiculo.valor_diaria * dias

        nova_reserva = Reserva(
            cliente_id=cliente.id,
            veiculo_id=veiculo.id,
            data_inicio=data_inicio,
            data_fim=data_fim,
            valor_total=valor_total
        )
        db.session.add(nova_reserva)
        veiculo.status = "Indisponível"
        db.session.commit()

        return nova_reserva
    


class Carro(Veiculo):
    __tablename__ = 'carro'
    id = db.Column(db.Integer, db.ForeignKey('veiculo.id'), primary_key=True)
    combustivel = db.Column(db.String(20))
    portas = db.Column(db.Integer)

    def __init__(self, tipo_veiculo, marca, modelo, placa, ano, cor, status, valor_diaria, combustivel, portas):
        super().__init__(tipo_veiculo, marca, modelo, placa, ano, cor, status, valor_diaria)
        self.combustivel = combustivel
        self.portas = portas

class Moto(Veiculo):
    __tablename__ = 'moto'
    id = db.Column(db.Integer, db.ForeignKey('veiculo.id'), primary_key=True)
    cilindradas = db.Column(db.Integer)
    partida_eletrica = db.Column(db.Boolean)

    def __init__(self, tipo_veiculo, marca, modelo, placa, ano, cor, status, valor_diaria, cilindradas, partida_eletrica):
        super().__init__(tipo_veiculo, marca, modelo, placa, ano, cor, status, valor_diaria)
        self.cilindradas = cilindradas
        self.partida_eletrica = partida_eletrica


class Reserva(db.Model):
    __tablename__ = 'reserva'
    id = db.Column(db.Integer, primary_key=True)
    cliente_id = db.Column(db.Integer, db.ForeignKey('cliente.id'))
    veiculo_id = db.Column(db.Integer, db.ForeignKey('veiculo.id'))
    data_inicio = db.Column(db.Date)
    data_fim = db.Column(db.Date)
    valor_total = db.Column(db.Float)

    cliente = db.relationship('Cliente', back_populates='reservas')
    veiculo = db.relationship('Veiculo', back_populates='reservas')

    # Apenas adicione isto, sem apagar nada acima
    def __init__(self, cliente, veiculo, data_inicio, data_fim, valor_total):
        self.cliente = cliente
        self.veiculo = veiculo
        self.data_inicio = data_inicio
        self.data_fim = data_fim
        self.valor_total = valor_total

